const p={"onlinekhabar.com":()=>r({title:"h1.ok__post-title, h1.entry-title, article h1",author:".ok__author-name, .author-name, .post-author",date:".ok__post-date, .post-date, time",content:".ok__post-content, .entry-content, article .post-content",image:".ok__featured-image img, .post-thumbnail img, article img"}),"ekantipur.com":()=>r({title:"h1.article-header, h1.story-title, article h1",author:".author-name, .writer-name, .article-author",date:".published-date, time, .article-date",content:".description, .story-content, .article-body",image:".article-image img, .story-image img"}),"setopati.com":()=>r({title:"h1.news-title, h1.entry-title, article h1",author:".author, .news-author, .reporter",date:".date, .news-date, time",content:".news-content, .entry-content, .news-body",image:".featured-image img, .news-image img"}),"nagariknews.com":()=>r({title:"h1",author:".author-name, .writer, .reporter-name",date:"time, .published-date, .article-date",content:".article-content, .news-detail, .story-body",image:".featured-img img, .article-img img"}),"ratopati.com":()=>r({title:"h1",author:".author, .writer",date:"time, .date",content:".news-content, .article-content, .post-content",image:".featured-image img"}),"dcnepal.com":()=>r({title:"h1.entry-title, article h1",author:".author, .entry-author",date:"time, .entry-date",content:".entry-content, .post-content",image:".post-thumbnail img, .entry-image img"})};function r(e){const t=document.querySelector(e.title),n=document.querySelector(e.content);if(!t||!n)return null;const a=document.querySelector(e.author),o=document.querySelector(e.date),u=document.querySelector(e.image);return{title:t.textContent?.trim()||"",author:a?.textContent?.trim()||"",date:o?.textContent?.trim()||o?.getAttribute("datetime")||"",content:n.innerHTML,siteName:window.location.hostname.replace(/^www\./,""),imageUrl:u?.src}}function g(){const e=["article",'[role="article"]',".post-content",".entry-content",".article-content",".news-content",".story-content","main .content"];let t=null;for(const a of e)if(t=document.querySelector(a),t)break;const n=document.querySelector("h1");return!n||!t?null:{title:n.textContent?.trim()||document.title,author:"",date:"",content:t.innerHTML,siteName:window.location.hostname.replace(/^www\./,"")}}function h(e){const t=document.createElement("div");t.id="nepali-ab-reader",t.innerHTML=`
    <div class="nar-container">
      <div class="nar-toolbar">
        <span class="nar-logo">📖 Clean Reader</span>
        <div class="nar-controls">
          <button class="nar-btn" id="nar-font-minus" title="Smaller text">A−</button>
          <button class="nar-btn" id="nar-font-plus" title="Larger text">A+</button>
          <button class="nar-btn" id="nar-theme-toggle" title="Toggle dark/light">🌓</button>
          <button class="nar-btn nar-close" id="nar-close" title="Close reader">✕</button>
        </div>
      </div>
      <article class="nar-article">
        <header>
          <h1 class="nar-title">${i(e.title)}</h1>
          <div class="nar-meta">
            ${e.author?`<span class="nar-author">✍️ ${i(e.author)}</span>`:""}
            ${e.date?`<span class="nar-date">📅 ${i(e.date)}</span>`:""}
            <span class="nar-source">📰 ${i(e.siteName)}</span>
          </div>
        </header>
        ${e.imageUrl?`<img class="nar-hero" src="${i(e.imageUrl)}" alt="">`:""}
        <div class="nar-content">${b(e.content)}</div>
      </article>
    </div>
  `;const n=document.createElement("style");n.textContent=f(),t.prepend(n),document.body.appendChild(t),document.body.style.overflow="hidden",document.getElementById("nar-close")?.addEventListener("click",m),document.getElementById("nar-font-minus")?.addEventListener("click",()=>d(-2)),document.getElementById("nar-font-plus")?.addEventListener("click",()=>d(2)),document.getElementById("nar-theme-toggle")?.addEventListener("click",x),document.addEventListener("keydown",s)}function i(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function b(e){const t=document.createElement("div");return t.innerHTML=e,t.querySelectorAll('script, style, iframe, .adsbygoogle, [class*="ad-"], [class*="social"], [class*="share"], [class*="related"], [class*="comment"], [class*="sidebar"], [class*="widget"], .sponsored, .advertisement, ins, [class*="newsletter"]').forEach(o=>o.remove()),t.querySelectorAll("div, span, p").forEach(o=>{!o.textContent?.trim()&&!o.querySelector("img")&&o.remove()}),t.innerHTML}let c=20,l=!0;function d(e){c=Math.max(14,Math.min(32,c+e));const t=document.querySelector(".nar-content");t&&(t.style.fontSize=`${c}px`)}function x(){l=!l,document.getElementById("nepali-ab-reader")?.classList.toggle("nar-light",!l)}function s(e){e.key==="Escape"&&m()}function m(){document.getElementById("nepali-ab-reader")?.remove(),document.body.style.overflow="",document.removeEventListener("keydown",s)}function f(){return`
    #nepali-ab-reader {
      position: fixed; inset: 0; z-index: 2147483647;
      background: #0d1117; color: #e6edf3;
      overflow-y: auto; font-family: 'Noto Sans Devanagari', 'Mukta', -apple-system, sans-serif;
    }
    #nepali-ab-reader.nar-light { background: #fafafa; color: #1a1a2e; }
    .nar-container { max-width: 720px; margin: 0 auto; padding: 0 24px 80px; }
    .nar-toolbar {
      position: sticky; top: 0; z-index: 10;
      display: flex; align-items: center; justify-content: space-between;
      padding: 12px 0; background: inherit;
      border-bottom: 1px solid rgba(255,255,255,0.1);
      margin-bottom: 32px;
    }
    #nepali-ab-reader.nar-light .nar-toolbar { border-color: rgba(0,0,0,0.1); }
    .nar-logo { font-size: 15px; font-weight: 700; }
    .nar-controls { display: flex; gap: 8px; }
    .nar-btn {
      padding: 6px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15);
      background: transparent; color: inherit; cursor: pointer; font-size: 13px; font-weight: 500;
      transition: all 0.15s;
    }
    .nar-btn:hover { background: rgba(255,255,255,0.08); }
    #nepali-ab-reader.nar-light .nar-btn { border-color: rgba(0,0,0,0.15); }
    #nepali-ab-reader.nar-light .nar-btn:hover { background: rgba(0,0,0,0.05); }
    .nar-close { color: #e94560; border-color: #e94560; }
    .nar-title {
      font-size: 32px; font-weight: 800; line-height: 1.3;
      margin: 0 0 16px; letter-spacing: -0.3px;
    }
    .nar-meta {
      display: flex; flex-wrap: wrap; gap: 16px;
      font-size: 14px; color: #8b949e; margin-bottom: 28px;
    }
    #nepali-ab-reader.nar-light .nar-meta { color: #666; }
    .nar-hero {
      width: 100%; border-radius: 12px; margin-bottom: 28px;
      max-height: 400px; object-fit: cover;
    }
    .nar-content {
      font-size: 20px; line-height: 1.9; word-spacing: 1px;
    }
    .nar-content p { margin: 0 0 1.4em; }
    .nar-content img { max-width: 100%; height: auto; border-radius: 8px; margin: 16px 0; }
    .nar-content h2, .nar-content h3 { margin: 1.8em 0 0.6em; font-weight: 700; }
    .nar-content a { color: #58a6ff; text-decoration: none; }
    #nepali-ab-reader.nar-light .nar-content a { color: #0969da; }
    .nar-content blockquote {
      margin: 1.2em 0; padding: 12px 20px;
      border-left: 3px solid #e94560; background: rgba(233,69,96,0.06);
      border-radius: 0 8px 8px 0;
    }
    /* Devanagari-optimized spacing */
    .nar-content { letter-spacing: 0.02em; }
    @media (max-width: 600px) {
      .nar-title { font-size: 24px; }
      .nar-content { font-size: 17px; }
    }
  `}function y(){const e=window.location.hostname.replace(/^www\./,""),t=p[e],n=t?t():g();if(!n||!n.title){const a=document.createElement("div");a.style.cssText=`
      position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
      z-index: 2147483647; background: #1a1a2e; color: #e94560;
      padding: 12px 24px; border-radius: 10px; font-size: 14px; font-weight: 600;
      box-shadow: 0 4px 20px rgba(0,0,0,0.4); border: 1px solid rgba(233,69,96,0.3);
    `,a.textContent="📖 Could not extract article content from this page.",document.body.appendChild(a),setTimeout(()=>a.remove(),3e3);return}h(n)}chrome.runtime.onMessage.addListener(e=>{e.type==="ACTIVATE_READER"&&y()});export{y as activateReader};
