let c=!1,r=null,l=null,u=null;const h="rgba(233, 69, 96, 0.35)",x="2px solid #e94560";function y(){const e=document.createElement("div");return e.id="nepali-ab-picker-highlight",e.style.cssText=`
    position: fixed;
    pointer-events: none;
    z-index: 2147483646;
    background: ${h};
    border: ${x};
    border-radius: 3px;
    transition: all 0.08s ease;
    display: none;
  `,document.documentElement.appendChild(e),e}function k(){const e=document.createElement("div");return e.id="nepali-ab-picker-toolbar",e.style.cssText=`
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 2147483647;
    background: #1a1a2e;
    color: #eee;
    padding: 12px 20px;
    border-radius: 12px;
    font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    font-size: 13px;
    display: flex;
    align-items: center;
    gap: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
    border: 1px solid rgba(255,255,255,0.1);
  `,e.innerHTML=`
    <span style="font-weight:600;">🎯 Element Picker</span>
    <span id="nepali-ab-picker-selector" style="color:#e94560; font-family:monospace; max-width:300px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">Hover over an element</span>
    <button id="nepali-ab-picker-block" style="padding:6px 14px; border-radius:8px; border:none; background:#e94560; color:white; font-weight:600; cursor:pointer; font-size:12px;">Block</button>
    <button id="nepali-ab-picker-zap" style="padding:6px 14px; border-radius:8px; border:none; background:#ff6b81; color:white; font-weight:600; cursor:pointer; font-size:12px;">Zap</button>
    <button id="nepali-ab-picker-cancel" style="padding:6px 14px; border-radius:8px; border:1px solid rgba(255,255,255,0.2); background:transparent; color:#aab; cursor:pointer; font-size:12px;">✕</button>
  `,document.documentElement.appendChild(e),e}function m(e){if(e.id&&!e.id.startsWith("nepali-ab"))return`#${CSS.escape(e.id)}`;const i=Array.from(e.classList).filter(o=>!o.startsWith("nepali-ab"));if(i.length>0){const o=i.map(a=>`.${CSS.escape(a)}`).join("");if(document.querySelectorAll(o).length<=3)return o}const n=[];let t=e,s=0;for(;t&&t!==document.body&&s<4;){let o=t.tagName.toLowerCase();if(t.id&&!t.id.startsWith("nepali-ab")){o=`#${CSS.escape(t.id)}`,n.unshift(o);break}const a=Array.from(t.classList).filter(d=>!d.startsWith("nepali-ab")).slice(0,2);a.length>0&&(o+=a.map(d=>`.${CSS.escape(d)}`).join("")),n.unshift(o),t=t.parentElement,s++}return n.join(" > ")}function b(e){if(!c||!r)return;const i=e.target;if(i.closest("#nepali-ab-picker-toolbar")||i.id?.startsWith("nepali-ab"))return;l=i;const n=i.getBoundingClientRect();r.style.display="block",r.style.top=`${n.top}px`,r.style.left=`${n.left}px`,r.style.width=`${n.width}px`,r.style.height=`${n.height}px`;const t=document.getElementById("nepali-ab-picker-selector");t&&(t.textContent=m(i))}function f(e){!c||e.target.closest("#nepali-ab-picker-toolbar")||(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}async function E(){if(!l)return;const e=m(l),n=`${window.location.hostname.replace(/^www\./,"")}##${e}`,s=(await chrome.storage.local.get("nepali_adblocker_custom_rules")).nepali_adblocker_custom_rules||"",o=s?`${s}
${n}`:n;await chrome.storage.local.set({nepali_adblocker_custom_rules:o}),l.style.setProperty("display","none","important");const a=document.createElement("style");a.setAttribute("data-nepali-adblocker","picker-rule"),a.textContent=`${e} { display: none !important; }`,document.head?.appendChild(a),p()}function v(){l&&(l.remove(),p())}function w(){c||(c=!0,r=y(),u=k(),document.addEventListener("mousemove",b,!0),document.addEventListener("click",f,!0),document.getElementById("nepali-ab-picker-block")?.addEventListener("click",E),document.getElementById("nepali-ab-picker-zap")?.addEventListener("click",v),document.getElementById("nepali-ab-picker-cancel")?.addEventListener("click",p),document.addEventListener("keydown",g))}function g(e){e.key==="Escape"&&p()}function p(){c=!1,document.removeEventListener("mousemove",b,!0),document.removeEventListener("click",f,!0),document.removeEventListener("keydown",g),r?.remove(),u?.remove(),r=null,u=null,l=null}chrome.runtime.onMessage.addListener(e=>{e.type==="ACTIVATE_PICKER"?w():e.type==="DEACTIVATE_PICKER"&&p()});export{w as activate,p as deactivate};
