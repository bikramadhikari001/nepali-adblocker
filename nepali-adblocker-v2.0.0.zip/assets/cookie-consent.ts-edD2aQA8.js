const t=["#cookie-notice","#cookie-consent","#cookie-banner","#cookie-popup","#cookieConsent","#cookie-law-info-bar","#cookie-bar",".cookie-notice",".cookie-consent",".cookie-banner",".cookie-popup",".cookie-bar",".cc-window",".cc-banner",".cc-overlay",'[class*="cookie-consent"]','[class*="cookie-banner"]','[class*="cookie-notice"]','[class*="cookie-popup"]','[id*="cookie-consent"]','[id*="cookie-banner"]','[id*="cookie-notice"]',"#gdpr-banner","#gdpr-consent",".gdpr-banner",".gdpr-consent",'[class*="gdpr"]',".privacy-banner",".privacy-notice",".consent-banner",".consent-popup",'[class*="consent-banner"]','[class*="consent-popup"]',"#cmpbox","#cmpbox2",".cmp-container",".cmp-modal","#sp_message_container",'[id^="sp_message"]',".qc-cmp-showing",".qc-cmp2-container","#onetrust-consent-sdk","#onetrust-banner-sdk",".onetrust-pc-dark-filter",".ot-sdk-container","#truste-consent-track","#truste-consent-content",'[class*="evidon"]',"#_evidon_banner","#_evidon-barrier-wrapper",".cookie-overlay",".consent-overlay",'[class*="cookie-backdrop"]',".cookie-modal-backdrop"],i=['[class*="cookie"] [class*="reject"]','[class*="cookie"] [class*="decline"]','[class*="cookie"] [class*="deny"]','[class*="cookie"] [class*="refuse"]','[class*="consent"] [class*="reject"]','[class*="consent"] [class*="decline"]','[class*="consent"] [class*="deny"]','button[data-action="reject"]','button[data-action="decline"]',"#onetrust-reject-all-handler",".js-reject-cookies",".cc-deny",".cc-dismiss",'[class*="cookie"] [class*="close"]','[class*="cookie"] [class*="dismiss"]','[class*="cookie"] [class*="accept-necessary"]','[class*="cookie"] [class*="necessary-only"]','[class*="consent"] [class*="close"]','[class*="consent"] [class*="dismiss"]','button[class*="cookie-close"]',".cookie-notice .close",".cookie-banner .close","#cookie-notice .dismiss",'[class*="cookie"] button[aria-label="Close"]','[class*="consent"] button[aria-label="Close"]','[id*="cookie"] button[aria-label="Close"]'];function a(){const o=t.join(`,
`)+` {
  display: none !important;
  visibility: hidden !important;
  opacity: 0 !important;
  pointer-events: none !important;
  height: 0 !important;
  max-height: 0 !important;
  overflow: hidden !important;
}

body.cookie-modal-open,
body.modal-open-cookie,
body[style*="overflow: hidden"] {
  overflow: auto !important;
}
`,e=document.createElement("style");e.setAttribute("data-nepali-adblocker","cookie-consent"),e.textContent=o,(document.head||document.documentElement).appendChild(e)}function c(){for(const o of i){const e=document.querySelector(o);if(e&&r(e))return e.click(),!0}return!1}function r(o){const e=o.getBoundingClientRect();return e.width>0&&e.height>0&&getComputedStyle(o).display!=="none"}function s(){let o=0;const e=10,n=new MutationObserver(()=>{o<e?c()&&o++:n.disconnect()});n.observe(document.documentElement,{childList:!0,subtree:!0}),setTimeout(()=>n.disconnect(),1e4)}function l(){a(),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{c(),s()}):(c(),s()),setTimeout(c,1500),setTimeout(c,3e3)}export{l as initCookieConsent};
